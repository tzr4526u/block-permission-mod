package com.example.blockpermissioncontrol;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class BlockPermissionControl implements ModInitializer {

    private static final Set<Block> ALLOWED_BLOCKS = new HashSet<>(Arrays.asList(
        Blocks.RED_WOOL,
        Blocks.BLUE_WOOL,
        Blocks.END_STONE,
        Blocks.GLASS,
        Blocks.OAK_WOOD,
        Blocks.OBSIDIAN,
        Blocks.RED_BED,
        Blocks.BLUE_BED
    ));

    @Override
    public void onInitialize() {
        PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, blockEntity) -> {
            if (!player.isCreative() && player.isInSurvival()) {
                return ALLOWED_BLOCKS.contains(state.getBlock());
            }
            return true;
        });

        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
            if (!player.isCreative() && player.isInSurvival()) {
                BlockPos pos = hitResult.getBlockPos();
                Block block = world.getBlockState(pos).getBlock();
                if (block == Blocks.RED_BED || block == Blocks.BLUE_BED) {
                    return ActionResult.FAIL;
                }
            }
            return ActionResult.PASS;
        });
    }
}
